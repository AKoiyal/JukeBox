import tkinter as tk
from tkinter import ttk
import app_style as style
from font_manager import FontManager
from track_library import TrackLibrary


class TrackUpdater:
    """GUI section for updating a track rating."""

    def __init__(self, window, library):
        self.window       = window
        self.library      = library
        self.selected_key = None
        self.rating_text  = tk.StringVar()
        self._setup_tree_style()
        self.build_widgets()
        self.refresh_tracks()

    def _setup_tree_style(self):
        s = ttk.Style()
        s.configure("Update.Treeview",
                     background=style.LIST_BG, foreground=style.TEXT,
                     fieldbackground=style.LIST_BG,
                     borderwidth=0, rowheight=28,
                     font=FontManager.BODY_FONT)
        s.configure("Update.Treeview.Heading",
                     background=style.PANEL_LIGHT, foreground=style.MUTED,
                     font=("Segoe UI", 10, "bold"),
                     borderwidth=0, relief="flat")
        s.map("Update.Treeview",
              background=[("selected", style.LIST_SELECT)],
              foreground=[("selected", style.TEXT_ON_DARK)])

    def build_widgets(self):
        tk.Label(self.window, text="Update Track Rating",
                 bg=style.PANEL, fg=style.ACCENT,
                 font=FontManager.SECTION_FONT
                 ).pack(anchor="w", pady=(0, 12))

        main = tk.Frame(self.window, bg=style.PANEL)
        main.pack(fill="both", expand=True)

        # treeview
        left = tk.Frame(main, bg=style.PANEL)
        left.pack(side="left", fill="both", expand=True, padx=(0, 12))

        tree_wrap = tk.Frame(left, bg=style.LIST_BG,
                             highlightthickness=1,
                             highlightbackground=style.BORDER)
        tree_wrap.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(
            tree_wrap,
            columns=("no", "track", "artist", "rating", "plays"),
            show="headings", style="Update.Treeview", selectmode="browse"
        )
        for col, h, w in [("no","No",46),("track","Track",260),
                           ("artist","Artist",180),("rating","Rating",90),("plays","Plays",60)]:
            self.tree.heading(col, text=h)
            self.tree.column(col, width=w, anchor="center" if col in ("no","rating","plays") else "w")
        self.tree.tag_configure("odd",  background=style.LIST_BG)
        self.tree.tag_configure("even", background="#111821")

        vsb = ttk.Scrollbar(tree_wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # right panel
        right = tk.Frame(main, bg=style.PANEL, width=220)
        right.pack(side="left", fill="y")
        right.pack_propagate(False)

        tk.Label(right, text="New Rating (0 – 5)",
                 bg=style.PANEL, fg=style.MUTED,
                 font=FontManager.SMALL_FONT).pack(anchor="w", pady=(0, 4))

        entry = tk.Entry(right, textvariable=self.rating_text, width=10,
                         bg=style.INPUT_BG, fg=style.TEXT,
                         insertbackground=style.TEXT,
                         relief="flat", bd=1,
                         highlightthickness=1,
                         highlightbackground=style.BORDER,
                         highlightcolor=style.ACCENT,
                         font=FontManager.BODY_FONT)
        entry.pack(anchor="w", ipady=6, pady=(0, 8))
        entry.bind("<Return>", self.update_rating_clicked)

        ttk.Button(right, text="✔  Update Rating",
                   command=self.update_rating_clicked,
                   style="Accent.TButton").pack(fill="x", pady=(0, 12))

        self.details = tk.Text(right, width=28, height=10, wrap="word")
        style.style_text(self.details)
        self.details.config(state="disabled")
        self.details.pack(fill="both", expand=True)

        self.status = tk.Label(self.window,
                               text="Click a track, enter a rating (0–5), then click Update.",
                               bg=style.PANEL, fg=style.MUTED,
                               font=FontManager.SMALL_FONT, anchor="w")
        self.status.pack(fill="x", pady=(8, 0))

    def refresh_tracks(self):
        self.tree.delete(*self.tree.get_children())
        for i, (key, item) in enumerate(self.library.get_all_items()):
            tag = "odd" if i % 2 == 0 else "even"
            self.tree.insert("", "end", iid=key,
                              values=(key, item.name, item.artist,
                                      item.stars(), item.play_count),
                              tags=(tag,))

    def refresh(self):
        self.refresh_tracks()

    def _set_details(self, text):
        self.details.config(state="normal")
        self.details.delete("1.0", tk.END)
        self.details.insert("1.0", text)
        self.details.config(state="disabled")

    def _on_select(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        key  = sel[0]
        item = self.library.get_item(key)
        if item is None:
            return
        self.selected_key = key
        self.rating_text.set(str(item.rating))
        self._set_details(
            f"Track #:  {key}\n"
            f"Name:     {item.name}\n"
            f"Artist:   {item.artist}\n"
            f"Rating:   {item.rating}/5\n"
            f"Stars:    {item.stars()}\n"
            f"Plays:    {item.play_count}\n"
        )
        self.status.config(text=f"Selected track {key}.")

    def update_rating_clicked(self, event=None):
        if self.selected_key is None:
            self.status.config(text="Please select a track first.")
            return
        raw = self.rating_text.get().strip()
        if not raw.isdigit():
            self.status.config(text="Rating must be a number from 0 to 5.")
            return
        rating = int(raw)
        if not 0 <= rating <= 5:
            self.status.config(text="Rating must be between 0 and 5.")
            return
        self.library.set_rating(self.selected_key, rating)
        item = self.library.get_item(self.selected_key)
        self._set_details(
            f"Updated ✔\n\n"
            f"Track #:  {self.selected_key}\n"
            f"Name:     {item.name}\n"
            f"Artist:   {item.artist}\n"
            f"New:      {item.rating}/5  {item.stars()}\n"
            f"Plays:    {item.play_count}\n"
        )
        self.refresh_tracks()
        self.tree.selection_set(self.selected_key)
        self.status.config(text=f"Track {self.selected_key} rating updated to {rating}.")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Update Tracks")
    style.setup_style(root)
    TrackUpdater(root, TrackLibrary())
    root.mainloop()
