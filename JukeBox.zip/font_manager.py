import tkinter.font as tkfont


class FontManager:
    """Stores and applies the fonts used in the JukeBox interface."""

    TITLE_FONT    = ("Segoe UI", 26, "bold")
    SECTION_FONT  = ("Segoe UI", 18, "bold")
    SUBTITLE_FONT = ("Segoe UI", 12, "bold")
    BODY_FONT     = ("Segoe UI", 11)
    SMALL_FONT    = ("Segoe UI", 10)
    LIST_FONT     = ("Consolas", 11)
    LIST_HEADER_FONT = ("Consolas", 11, "bold")

    def __init__(self, family="Segoe UI", fixed_family="Consolas"):
        self.family       = family
        self.fixed_family = fixed_family

    def configure(self):
        tkfont.nametofont("TkDefaultFont").configure(size=11, family=self.family)
        tkfont.nametofont("TkTextFont").configure(size=11, family=self.family)
        tkfont.nametofont("TkFixedFont").configure(size=11, family=self.fixed_family)
        try:
            tkfont.nametofont("TkHeadingFont").configure(size=12, family=self.family, weight="bold")
            tkfont.nametofont("TkMenuFont").configure(size=10, family=self.family)
        except Exception:
            pass
