import os
import tkinter as tk
from tkinter import filedialog, ttk
import app_style as style
from font_manager import FontManager
from track_library import TrackLibrary


class TrackAdder:
    """GUI section for adding a new track with music and image files."""

    def __init__(self, window, library):
        self.window   = window
        self.library  = library

        self.name_text   = tk.StringVar()
        self.artist_text = tk.StringVar()
        self.rating_text = tk.StringVar(value="0")
        self.audio_text  = tk.StringVar()
        self.image_text  = tk.StringVar()

        self.build_widgets()

    def build_widgets(self):
        tk.Label(self.window, text="Add Track",
                 bg=style.PANEL, fg=style.ACCENT,
                 font=FontManager.SECTION_FONT
                 ).pack(anchor="w", pady=(0, 16))

        form_outer = tk.Frame(self.window, bg=style.PANEL)
        form_outer.pack(fill="x")

        form = tk.Frame(form_outer, bg=style.PANEL_LIGHT, padx=24, pady=20)
        form.pack(fill="x", ipadx=4, ipady=4)

        def make_label(row, text):
            tk.Label(form, text=text,
                     bg=style.PANEL_LIGHT, fg=style.MUTED,
                     font=FontManager.SMALL_FONT,
                     anchor="w", width=14
                     ).grid(row=row, column=0, sticky="w", pady=8)

        def make_entry(row, var):
            e = tk.Entry(form, textvariable=var, width=44,
                         bg=style.INPUT_BG, fg=style.TEXT,
                         insertbackground=style.TEXT,
                         relief="flat", bd=1,
                         highlightthickness=1,
                         highlightbackground=style.BORDER,
                         highlightcolor=style.ACCENT,
                         font=FontManager.BODY_FONT)
            e.grid(row=row, column=1, sticky="ew", pady=8, ipady=6)
            return e

        make_label(0, "Track Name")
        make_entry(0, self.name_text)

        make_label(1, "Artist")
        make_entry(1, self.artist_text)

        make_label(2, "Rating (0–5)")
        make_entry(2, self.rating_text)

        make_label(3, "Music File")
        make_entry(3, self.audio_text)
        ttk.Button(form, text="Browse", command=self._choose_audio
                   ).grid(row=3, column=2, padx=(8, 0))

        make_label(4, "Image File")
        make_entry(4, self.image_text)
        ttk.Button(form, text="Browse", command=self._choose_image
                   ).grid(row=4, column=2, padx=(8, 0))

        form.columnconfigure(1, weight=1)

        ttk.Button(form, text="➕  Add Track",
                   command=self._add_track_clicked,
                   style="Accent.TButton"
                   ).grid(row=5, column=0, columnspan=3,
                          sticky="ew", pady=(16, 0))

        self.status = tk.Label(self.window,
                               text="Fill in the fields above and click Add Track.",
                               bg=style.PANEL, fg=style.MUTED,
                               font=FontManager.SMALL_FONT, anchor="w")
        self.status.pack(fill="x", pady=(12, 0))

    def _choose_audio(self):
        path = filedialog.askopenfilename(
            title="Choose Music File",
            filetypes=[("Audio files", "*.mp3 *.wav *.ogg"), ("All files", "*.*")])
        if path:
            self.audio_text.set(path)

    def _choose_image(self):
        path = filedialog.askopenfilename(
            title="Choose Image File",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.webp"), ("All files", "*.*")])
        if path:
            self.image_text.set(path)

    def _add_track_clicked(self):
        name   = self.name_text.get().strip()
        artist = self.artist_text.get().strip()
        raw    = self.rating_text.get().strip()
        audio  = self.audio_text.get().strip()
        image  = self.image_text.get().strip()

        if not name or not artist:
            self.status.config(text="⚠  Track name and artist are required.")
            return
        if not raw.isdigit():
            self.status.config(text="⚠  Rating must be a number from 0 to 5.")
            return
        rating = int(raw)
        if not 0 <= rating <= 5:
            self.status.config(text="⚠  Rating must be between 0 and 5.")
            return
        if audio and not os.path.exists(audio):
            self.status.config(text="⚠  Music file not found.")
            return
        if image and not os.path.exists(image):
            self.status.config(text="⚠  Image file not found.")
            return

        key = self.library.add_track(name, artist, rating, audio, image)
        self.name_text.set("")
        self.artist_text.set("")
        self.rating_text.set("0")
        self.audio_text.set("")
        self.image_text.set("")
        self.status.config(text=f"✔  Track added successfully as number {key}.")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Add Track")
    style.setup_style(root)
    TrackAdder(root, TrackLibrary())
    root.mainloop()
