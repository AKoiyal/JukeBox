import os
from library_item import AlbumTrack, LibraryItem


class TrackLibrary:
    """Stores all tracks used by the JukeBox program."""

    def __init__(self):
        self.library = {}
        base_dir = os.path.dirname(os.path.abspath(__file__))
        music_dir = os.path.join(base_dir, "Music links")
        image_dir = os.path.join(base_dir, "music image")

        self.library["01"] = AlbumTrack(
            "Another Brick in the Wall", "Pink Floyd", "The Wall", 4,
            os.path.join(music_dir, "pink floyd - another brick in the wall - Piccologollum (youtube).mp3"),
            os.path.join(image_dir, "another-brick-in-the-wall-1.jpg"))
        self.library["02"] = AlbumTrack(
            "Highway to Hell", "AC/DC", "Highway to Hell", 3,
            os.path.join(music_dir, "AC_DC - Highway to Hell (Official Video) - acdcVEVO (youtube).mp3"),
            os.path.join(image_dir, "acdc-highway-to-hell.webp"))
        self.library["03"] = AlbumTrack(
            "Someone Like You", "Adele", "21", 5,
            os.path.join(music_dir, "Adele - Someone Like You (Official Music Video) - Adele (youtube).mp3"),
            os.path.join(image_dir, "sly-25-fbevent-1920.jpg"))
        self.library["04"] = LibraryItem(
            "E85", "Don Toliver", 3,
            os.path.join(music_dir, "Don Toliver - E85 [Official Visualizer] - Don Toliver (youtube).mp3"),
            os.path.join(image_dir, "don-toliver-pr-credit-ryan-schude-billboard-1800.webp"))
        self.library["05"] = LibraryItem(
            "Shape of You", "Ed Sheeran", 4,
            os.path.join(music_dir, "Ed Sheeran - Shape Of You [Official Lyric Video] - Ed Sheeran (youtube).mp3"),
            os.path.join(image_dir, "x1080.jpeg"))
        self.library["06"] = AlbumTrack(
            "Goddess", "Laufey", "Bewitched", 5,
            os.path.join(music_dir, "Laufey - Goddess (Official Audio With Lyrics) - Laufey (youtube).mp3"),
            os.path.join(image_dir, "laufey-exc-interview.webp"))
        self.library["07"] = LibraryItem(
            "Promise", "Laufey", 5,
            os.path.join(music_dir, "Laufey - Promise (Official Audio) - Laufey (youtube).mp3"),
            os.path.join(image_dir, "maxresdefault.jpg"))
        self.library["08"] = LibraryItem(
            "Happier", "Olivia Rodrigo", 4,
            os.path.join(music_dir, "Olivia Rodrigo - happier (Lyric Video) - OliviaRodrigoVEVO (youtube).mp3"),
            os.path.join(image_dir, "maxresdefault (1).jpg"))
        self.library["09"] = LibraryItem(
            "Underdog", "Roddy Ricch", 3,
            os.path.join(music_dir, "Roddy Ricch - Underdog (From F1® The Movie) [Official Visualizer] - Roddy Ricch (youtube).mp3"),
            os.path.join(image_dir, "maxresdefault (2).jpg"))
        self.library["10"] = LibraryItem(
            "In My Blood", "Shawn Mendes", 4,
            os.path.join(music_dir, "Shawn Mendes - In My Blood - ShawnMendesVEVO (youtube).mp3"),
            os.path.join(image_dir, "R-12370234-1533892125-7281.jpg"))
        self.library["11"] = LibraryItem(
            "Purple Lace Bra", "Tate McRae", 3,
            os.path.join(music_dir, "Tate McRae - Purple lace bra (Lyric Video) - TateMcRaeVEVO (youtube).mp3"),
            os.path.join(image_dir, "tate_mcrae_tracklist.webp"))
        self.library["12"] = LibraryItem(
            "Roses", "The Chainsmokers ft. ROZES", 4,
            os.path.join(music_dir, "The Chainsmokers - Roses (Official Audio) ft. ROZES - ChainsmokersVEVO (youtube).mp3"),
            os.path.join(image_dir, "1200x630wp-60.jpg"))

    def get_item(self, key):
        return self.library.get(self.fix_key(key))

    def fix_key(self, key):
        key = str(key).strip()
        if key.isdigit():
            return key.zfill(2)
        return key

    def list_all(self):
        output = ""
        for key, item in self.library.items():
            output += f"{key} {item.info()} Plays: {item.play_count}\n"
        return output

    def get_name(self, key):
        item = self.get_item(key)
        return item.name if item else None

    def get_artist(self, key):
        item = self.get_item(key)
        return item.artist if item else None

    def get_rating(self, key):
        item = self.get_item(key)
        return item.rating if item else -1

    def get_play_count(self, key):
        item = self.get_item(key)
        return item.play_count if item else -1

    def get_audio_path(self, key):
        item = self.get_item(key)
        return item.audio_path if item else ""

    def get_image_path(self, key):
        item = self.get_item(key)
        return item.image_path if item else ""

    def set_rating(self, key, rating):
        item = self.get_item(key)
        if item is None:
            return False
        item.set_rating(rating)
        return True

    def increment_play_count(self, key):
        item = self.get_item(key)
        if item is not None:
            item.increment_play_count()

    def get_all_keys(self):
        return list(self.library.keys())

    def get_all_items(self):
        return list(self.library.items())

    def get_artists(self):
        artists = []
        for item in self.library.values():
            if item.artist not in artists:
                artists.append(item.artist)
        return sorted(artists)

    def search(self, keyword):
        results = {}
        keyword = keyword.strip()
        if keyword == "":
            return results
        for key, item in self.library.items():
            if item.matches_keyword(keyword):
                results[key] = item
        return results

    def filter_by_artist(self, artist):
        results = {}
        for key, item in self.library.items():
            if item.matches_artist(artist):
                results[key] = item
        return results

    def get_next_key(self):
        numbers = [int(key) for key in self.library.keys() if key.isdigit()]
        return f"{max(numbers) + 1:02d}"

    def add_track(self, name, artist, rating=0, audio_path="", image_path=""):
        key = self.get_next_key()
        self.library[key] = LibraryItem(name, artist, rating, audio_path, image_path)
        return key
