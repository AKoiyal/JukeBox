from library_item import LibraryItem, AlbumTrack

# Test LibraryItem basic attributes
def test_name():
    item = LibraryItem("Shape of You", "Ed Sheeran", 4)
    assert item.name == "Shape of You"

def test_artist():
    item = LibraryItem("Shape of You", "Ed Sheeran", 4)
    assert item.artist == "Ed Sheeran"

def test_default_play_count():
    item = LibraryItem("Shape of You", "Ed Sheeran", 4)
    assert item.play_count == 0

# Test rating validation
def test_valid_rating():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    item.set_rating(5)
    assert item.rating == 5

def test_invalid_rating_too_high():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    item.set_rating(9)
    assert item.rating == 3

def test_invalid_rating_too_low():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    item.set_rating(-1)
    assert item.rating == 3

# Test play count
def test_increment_play_count():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    item.increment_play_count()
    assert item.play_count == 1

def test_increment_multiple():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    item.increment_play_count()
    item.increment_play_count()
    assert item.play_count == 2

# Test stars output
def test_stars():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    assert item.stars() == "★★★☆☆"

def test_stars_zero():
    item = LibraryItem("Shape of You", "Ed Sheeran", 0)
    assert item.stars() == "☆☆☆☆☆"

# Test keyword matching
def test_matches_keyword_name():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    assert item.matches_keyword("shape") is True

def test_matches_keyword_artist():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    assert item.matches_keyword("sheeran") is True

def test_matches_keyword_no_match():
    item = LibraryItem("Shape of You", "Ed Sheeran", 3)
    assert item.matches_keyword("beyonce") is False

# Test AlbumTrack inheritance
def test_album_track_album():
    track = AlbumTrack("Bohemian Rhapsody", "Queen", "A Night at the Opera", 5)
    assert track.album == "A Night at the Opera"

def test_album_track_keyword_album():
    track = AlbumTrack("Bohemian Rhapsody", "Queen", "A Night at the Opera", 5)
    assert track.matches_keyword("opera") is True