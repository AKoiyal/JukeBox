import os
import tkinter as tk
from tkinter import ttk

try:
    import pygame
    pygame.mixer.init()
    HAS_PYGAME = True
except Exception:
    HAS_PYGAME = False

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from add_track import TrackAdder
import app_style as style
from create_track_list import TrackListCreator
from font_manager import FontManager
from track_library import TrackLibrary
from update_tracks import TrackUpdater
from view_tracks import TrackViewer


class JukeBox:
    """Main window that connects all sections of the jukebox app."""

    def __init__(self, window):
        self.window = window
        self.window.title("JukeBox")
        self.window.geometry("1220x740")
        self.window.minsize(900, 600)
        style.setup_style(self.window)

        self.library = TrackLibrary()
        self.sections = {}
        self.section_objects = {}
        self.nav_buttons = {}
        self.current_section = None
        self.current_key = None
        self.current_photo = None
        self.is_paused = False
        self.track_length = 0
        self.progress_job = None
        self.volume = tk.DoubleVar(value=70)
        self.current_queue = []
        self.queue_index = 0

        self.build_widgets()
        # Show default section after widgets are built
        self.show_section("view")

    # ── Layout ────────────────────────────────────────────────────────────────
    def build_widgets(self):
        # ── Top header bar
        header = tk.Frame(self.window, bg=style.PANEL, height=56)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(
            header,
            text="♪ JukeBox",
            bg=style.PANEL,
            fg=style.ACCENT,
            font=FontManager.TITLE_FONT
        ).pack(side="left", padx=(20, 6), pady=10)

        tk.Label(
            header,
            text="Music library, playlist and rating manager",
            bg=style.PANEL,
            fg=style.MUTED,
            font=("Segoe UI", 10)
        ).pack(side="left", pady=10)

        # thin accent line under header
        tk.Frame(self.window, bg=style.ACCENT, height=2).pack(fill="x")

        # ── Body (sidebar + content)
        body = tk.Frame(self.window, bg=style.BG)
        body.pack(fill="both", expand=True)

        # ── Sidebar
        sidebar = tk.Frame(body, bg=style.PANEL, width=190)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(
            sidebar,
            text="MENU",
            bg=style.PANEL,
            fg=style.MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", padx=18, pady=(18, 8))

        nav_items = [
            ("view",     "🎵  View Tracks"),
            ("playlist", "📋  Create Track List"),
            ("update",   "✏️   Update Tracks"),
            ("add",      "➕  Add Track"),
        ]
        for key, label in nav_items:
            btn = ttk.Button(
                sidebar, text=label,
                command=lambda k=key: self.show_section(k),
                style="Nav.TButton"
            )
            btn.pack(fill="x", padx=10, pady=3)
            self.nav_buttons[key] = btn

        tk.Label(
            sidebar,
            text="v2.0",
            bg=style.PANEL,
            fg=style.MUTED,
            font=("Segoe UI", 9)
        ).pack(side="bottom", pady=12)

        # ── Content area — single frame, sections packed/unpacked inside
        self.content = tk.Frame(body, bg=style.PANEL)
        self.content.pack(side="left", fill="both", expand=True,
                          padx=14, pady=14)

        # Build each section frame (NOT packed yet — show_section does that)
        self.sections["view"] = ttk.Frame(self.content, style="Card.TFrame",
                                          padding=16)
        self.sections["playlist"] = ttk.Frame(self.content, style="Card.TFrame",
                                              padding=16)
        self.sections["update"] = ttk.Frame(self.content, style="Card.TFrame",
                                            padding=16)
        self.sections["add"] = ttk.Frame(self.content, style="Card.TFrame",
                                         padding=16)

        # Attach section controllers to their frames
        self.section_objects["view"] = TrackViewer(
            self.sections["view"], self.library, self.play_track)
        self.section_objects["playlist"] = TrackListCreator(
            self.sections["playlist"], self.library, self.play_queue)
        self.section_objects["update"] = TrackUpdater(
            self.sections["update"], self.library)
        self.section_objects["add"] = TrackAdder(
            self.sections["add"], self.library)

        # ── Player bar
        tk.Frame(self.window, bg=style.BORDER, height=1).pack(fill="x")

        player = tk.Frame(self.window, bg=style.PANEL_LIGHT, padx=16, pady=12)
        player.pack(fill="x")

        # album art thumbnail
        self.art_label = tk.Label(
            player, text="♪",
            bg=style.PANEL_LIGHT, fg=style.MUTED,
            font=("Segoe UI", 20),
            width=4, anchor="center"
        )
        self.art_label.pack(side="left", padx=(0, 12))

        # info + progress
        info_area = tk.Frame(player, bg=style.PANEL_LIGHT)
        info_area.pack(side="left", fill="x", expand=True)

        self.now_playing = tk.Label(
            info_area,
            text="No track playing",
            bg=style.PANEL_LIGHT,
            fg=style.TEXT_ON_DARK,
            font=FontManager.SUBTITLE_FONT
        )
        self.now_playing.pack(anchor="w")

        progress_row = tk.Frame(info_area, bg=style.PANEL_LIGHT)
        progress_row.pack(fill="x", pady=(6, 0))

        self.time_label = tk.Label(
            progress_row, text="0:00",
            bg=style.PANEL_LIGHT, fg=style.MUTED,
            font=FontManager.SMALL_FONT
        )
        self.time_label.pack(side="left", padx=(0, 8))

        self.progress_canvas = tk.Canvas(
            progress_row, height=6,
            bg=style.PROGRESS_BG,
            highlightthickness=0, relief="flat"
        )
        self.progress_canvas.pack(side="left", fill="x", expand=True)

        self.duration_label = tk.Label(
            progress_row, text="0:00",
            bg=style.PANEL_LIGHT, fg=style.MUTED,
            font=FontManager.SMALL_FONT
        )
        self.duration_label.pack(side="left", padx=(8, 16))

        # playback controls
        controls = tk.Frame(player, bg=style.PANEL_LIGHT)
        controls.pack(side="left", padx=(0, 12))

        ttk.Button(controls, text="⏮ Prev",
                   command=self.previous_track).pack(side="left", padx=3)
        ttk.Button(controls, text="⏯ Play",
                   command=self.toggle_pause,
                   style="Accent.TButton").pack(side="left", padx=3)
        ttk.Button(controls, text="⏭ Next",
                   command=self.next_track).pack(side="left", padx=3)
        ttk.Button(controls, text="⏹ Stop",
                   command=self.stop_music).pack(side="left", padx=3)

        # volume
        vol_box = tk.Frame(player, bg=style.PANEL_LIGHT)
        vol_box.pack(side="left", padx=(8, 0))

        tk.Label(
            vol_box, text="🔊 Volume",
            bg=style.PANEL_LIGHT, fg=style.MUTED,
            font=FontManager.SMALL_FONT
        ).pack(anchor="w")

        self.volume_slider = ttk.Scale(
            vol_box, from_=0, to=100,
            orient="horizontal",
            variable=self.volume,
            command=self.change_volume,
            length=110
        )
        self.volume_slider.pack()

    # ── Navigation ────────────────────────────────────────────────────────────
    def show_section(self, name):
        """
        Switch the visible section by packing the chosen frame and
        unpacking all others. This avoids place()/tkraise() timing issues.
        """
        # Unpack whichever section is currently showing
        for key, frame in self.sections.items():
            frame.pack_forget()

        # Pack the requested section so it fills the content area
        self.sections[name].pack(fill="both", expand=True)
        self.current_section = name

        # Update nav button styles — active vs inactive
        for key, btn in self.nav_buttons.items():
            btn.configure(
                style="Nav.Active.TButton" if key == name else "Nav.TButton"
            )

        # Refresh section data if the section supports it
        section = self.section_objects.get(name)
        if hasattr(section, "refresh"):
            section.refresh()

    # ── Playback ──────────────────────────────────────────────────────────────
    def play_track(self, key, count_play=True):
        item = self.library.get_item(key)
        if item is None:
            self.now_playing.config(text="Track not found")
            return

        if (self.current_section == "view"
                or not self.current_queue
                or key not in self.current_queue):
            self.current_queue = self.library.get_all_keys()
            if key in self.current_queue:
                self.queue_index = self.current_queue.index(key)

        if self.progress_job is not None:
            self.window.after_cancel(self.progress_job)
            self.progress_job = None

        self.current_key = key
        self.is_paused = False
        self.track_length = 0
        self.update_progress_bar(0)

        if count_play:
            self.library.increment_play_count(key)

        self.now_playing.config(text=f"Now Playing:  {item.name} — {item.artist}")
        self.show_now_playing_image(item.image_path)

        if not HAS_PYGAME:
            return

        if item.audio_path and os.path.exists(item.audio_path):
            pygame.mixer.music.load(item.audio_path)
        else:
            self.status.config(text="Audio file not found.")
            return
            pygame.mixer.music.set_volume(self.volume.get() / 100)
            self.track_length = self._get_track_length(item.audio_path)
            self.duration_label.config(text=self._fmt(self.track_length))
            pygame.mixer.music.play()
            self._update_progress()

    def play_queue(self, queue, start_index=0):
        if not queue:
            return
        self.current_queue = list(queue)
        self.queue_index = start_index
        self.play_track(self.current_queue[self.queue_index], count_play=False)

    def next_track(self):
        if not self.current_queue:
            self.current_queue = self.library.get_all_keys()
        if not self.current_queue:
            return
        self.queue_index = (self.queue_index + 1) % len(self.current_queue)
        self.play_track(self.current_queue[self.queue_index])

    def previous_track(self):
        if not self.current_queue:
            self.current_queue = self.library.get_all_keys()
        if not self.current_queue:
            return
        self.queue_index = (self.queue_index - 1) % len(self.current_queue)
        self.play_track(self.current_queue[self.queue_index])

    def toggle_pause(self):
        if not HAS_PYGAME or self.current_key is None:
            return
        if self.is_paused:
            pygame.mixer.music.unpause()
            self.is_paused = False
            self._update_progress()
        else:
            pygame.mixer.music.pause()
            self.is_paused = True

    def stop_music(self):
        if self.progress_job is not None:
            self.window.after_cancel(self.progress_job)
            self.progress_job = None
        if HAS_PYGAME:
            pygame.mixer.music.stop()
        self.current_key = None
        self.is_paused = False
        self.track_length = 0
        self.now_playing.config(text="No track playing")
        self.time_label.config(text="0:00")
        self.duration_label.config(text="0:00")
        self.update_progress_bar(0)

    def change_volume(self, value):
        if HAS_PYGAME:
            pygame.mixer.music.set_volume(float(value) / 100)

    # ── Progress bar ──────────────────────────────────────────────────────────
    def _get_track_length(self, audio_path):
        try:
            return int(pygame.mixer.Sound(audio_path).get_length())
        except Exception:
            return 0

    def _fmt(self, seconds):
        return f"{seconds // 60}:{seconds % 60:02d}"

    def _update_progress(self):
        if not HAS_PYGAME or self.current_key is None or self.is_paused:
            return
        pos = pygame.mixer.music.get_pos()
        secs = max(0, pos) // 1000
        self.time_label.config(text=self._fmt(secs))
        if self.track_length > 0:
            self.update_progress_bar(secs / self.track_length)
        if pygame.mixer.music.get_busy():
            self.progress_job = self.window.after(500, self._update_progress)
        else:
            self.update_progress_bar(0)

    # keep old name for compatibility
    def update_progress(self):
        self._update_progress()

    def update_progress_bar(self, fraction):
        fraction = max(0.0, min(1.0, fraction))
        self.progress_canvas.delete("all")
        w = self.progress_canvas.winfo_width() or 300
        h = 6
        self.progress_canvas.create_rectangle(
            0, 1, w, h - 1, fill=style.PROGRESS_BG, outline="")
        if fraction > 0:
            self.progress_canvas.create_rectangle(
                0, 1, w * fraction, h - 1, fill=style.ACCENT, outline="")

    # ── Album art ─────────────────────────────────────────────────────────────
    def show_now_playing_image(self, image_path):
        if not HAS_PIL or not image_path or not os.path.exists(image_path):
            self.current_photo = None
            self.art_label.config(image="", text="♪")
            return
        img = Image.open(image_path).resize((52, 52))
        self.current_photo = ImageTk.PhotoImage(img)
        self.art_label.config(image=self.current_photo, text="")


if __name__ == "__main__":
    root = tk.Tk()
    JukeBox(root)
    root.mainloop()
