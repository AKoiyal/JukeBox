# create_track_list.py
# This module defines the TrackListCreator class, which provides the
# "Create Track List" section of the JukeBox application.
# It allows the user to build a playlist from the library, play it,
# and save/load playlists as CSV files.

import csv
import os
import tkinter as tk
from tkinter import filedialog, ttk

import app_style as style
from font_manager import FontManager
from track_library import TrackLibrary


class TrackListCreator:
    """GUI section for creating, managing, saving and loading playlists."""

    def __init__(self, window, library, on_play_queue=None):
        """
        Initialise the TrackListCreator.

        Parameters:
            window        - the parent Tkinter frame this section is placed inside
            library       - a TrackLibrary instance providing access to all track data
            on_play_queue - optional callback called with (playlist, start_index) to
                            trigger actual audio playback via the main JukeBox window
        """
        self.window = window                # parent frame (section container)
        self.library = library              # shared track database
        self.on_play_queue = on_play_queue  # playback callback from JukeBox
        self.playlist = []                  # list of track key strings, e.g. ["01", "05", "08"]

        self.build_widgets()    # construct all GUI elements
        self.refresh_library()  # populate the library list on startup

    # -------------------------------------------------------------------------
    # Widget Construction
    # -------------------------------------------------------------------------

    def build_widgets(self):
        """Build and arrange all GUI widgets for this section."""

        # Section title label
        title = tk.Label(
            self.window,
            text="Create Track List",
            bg=style.PANEL,
            fg=style.ACCENT,
            font=FontManager.SECTION_FONT
        )
        title.pack(anchor="w", pady=(0, 10))

        # --- Main 3-column layout: Library | Buttons | Playlist ---
        main = ttk.Frame(self.window, style="Card.TFrame")
        main.pack(fill="both", expand=True)

        # Left column: Track Library list
        library_frame = ttk.LabelFrame(main, text="Track Library")
        library_frame.pack(side="left", fill="both", expand=True, padx=(0, 8))

        self.library_list = tk.Listbox(library_frame, height=18)
        style.style_listbox(self.library_list)
        self.library_list.pack(fill="both", expand=True, padx=5, pady=5)
        # Double-click on library item adds it to the playlist
        self.library_list.bind("<Double-Button-1>", self.add_track_clicked)

        # Centre column: Action buttons
        buttons = ttk.Frame(main)
        buttons.pack(side="left", fill="y", padx=5)

        # Add > : adds the selected library track to the playlist
        ttk.Button(buttons, text="Add >",
                   command=self.add_track_clicked,
                   style="Accent.TButton").pack(fill="x", pady=4)

        # Play Playlist: plays all tracks in order and increments their play counts
        ttk.Button(buttons, text="Play Playlist",
                   command=self.play_playlist_clicked,
                   style="Purple.TButton").pack(fill="x", pady=4)

        # Remove Selected: removes the highlighted track from the playlist
        ttk.Button(buttons, text="Remove Selected",
                   command=self.remove_selected_clicked).pack(fill="x", pady=4)

        # Reset: clears the entire playlist
        ttk.Button(buttons, text="Reset",
                   command=self.reset_playlist_clicked).pack(fill="x", pady=4)

        # Save / Load Playlist buttons (separated by extra padding for visual grouping)
        ttk.Button(buttons, text="Save Playlist",
                   command=self.save_playlist_clicked).pack(fill="x", pady=(18, 4))
        ttk.Button(buttons, text="Load Playlist",
                   command=self.load_playlist_clicked).pack(fill="x", pady=4)

        # Right column: Current playlist
        playlist_frame = ttk.LabelFrame(main, text="Playlist")
        playlist_frame.pack(side="left", fill="both", expand=True, padx=(8, 0))

        self.playlist_list = tk.Listbox(playlist_frame, height=18)
        style.style_listbox(self.playlist_list)
        self.playlist_list.pack(fill="both", expand=True, padx=5, pady=5)
        # Double-click on playlist item starts playback from that position
        self.playlist_list.bind("<Double-Button-1>", self.play_from_double_click)

        # Status bar: user feedback messages at the bottom
        self.status = ttk.Label(self.window,
                                text="Double-click a track to add it.",
                                style="Status.TLabel")
        self.status.pack(fill="x", pady=(10, 0))

    # -------------------------------------------------------------------------
    # List Refresh Methods
    # -------------------------------------------------------------------------

    def refresh_library(self):
        """Repopulate the library Listbox with all current tracks from the library."""
        self.library_list.delete(0, tk.END)  # clear existing rows
        # Insert a column header row (not selectable as a track)
        self.library_list.insert(tk.END, f"{'No':<4}{'Track':<32}{'Artist':<22}{'Rating':<10}")
        # Insert one row per track in the library
        for key, item in self.library.get_all_items():
            row = (
                f"{key:<4}"
                f"{item.name[:30]:<32}"    # truncate long names to prevent overflow
                f"{item.artist[:20]:<22}"
                f"{item.stars():<10}"
            )
            self.library_list.insert(tk.END, row)

    def refresh_playlist(self):
        """Repopulate the playlist Listbox with the current contents of self.playlist."""
        self.playlist_list.delete(0, tk.END)  # clear existing rows
        # Insert a column header row
        self.playlist_list.insert(tk.END, f"{'No':<4}{'Track':<32}{'Artist':<22}")
        # Insert one row per key in the playlist
        for key in self.playlist:
            item = self.library.get_item(key)   # look up the LibraryItem by key
            if item is not None:
                row = (
                    f"{key:<4}"
                    f"{item.name[:30]:<32}"
                    f"{item.artist[:20]:<22}"
                )
                self.playlist_list.insert(tk.END, row)

    def refresh(self):
        """Refresh both the library and playlist displays. Called on section switch."""
        self.refresh_library()
        self.refresh_playlist()

    # -------------------------------------------------------------------------
    # Selection Helper Methods
    # -------------------------------------------------------------------------

    def get_selected_library_key(self):
        """
        Return the track key of the currently highlighted row in the library Listbox.
        Returns None if nothing is selected or if the header row is selected.
        """
        selected = self.library_list.curselection()  # tuple of selected row indices
        if not selected:
            return None
        line = self.library_list.get(selected[0])    # text of the selected row
        if line.startswith("No"):                     # skip the header row
            return None
        return line.split()[0]                        # key is the first token (e.g. "04")

    def get_selected_playlist_index(self):
        """
        Return the zero-based index into self.playlist for the highlighted playlist row.
        Returns None if nothing is selected or the header row is selected.
        Note: index 0 in the Listbox is the header, so playlist index = Listbox index - 1.
        """
        selected = self.playlist_list.curselection()
        if not selected:
            return None
        if selected[0] == 0:    # index 0 is the header row, not a track
            return None
        return selected[0] - 1  # offset by 1 to align with self.playlist list

    # -------------------------------------------------------------------------
    # Button Action Methods
    # -------------------------------------------------------------------------

    def add_track_clicked(self, event=None):
        """
        Add the selected library track to the playlist.
        Validates that a track is selected and checks for duplicates.
        """
        key = self.get_selected_library_key()
        if key is None:
            self.status.config(text="Select a track from the library first.")
            return
        if self.library.get_item(key) is None:
            # This guard handles cases where the key somehow doesn't exist in the library
            self.status.config(text="Invalid track number.")
            return
        # Prevent duplicate entries in the playlist
        if key in self.playlist:
            self.status.config(text=f"⚠  Track {key} is already in the playlist.")
            return

        self.playlist.append(key)       # add the key to the in-memory playlist list
        self.refresh_playlist()         # update the displayed playlist Listbox
        self.status.config(text=f"Track {key} added to playlist.")

    def play_playlist_clicked(self):
        """
        Play the entire playlist from the beginning.
        Increments the play count for every track in the playlist,
        then delegates audio playback to the JukeBox callback if available.
        """
        if not self.playlist:
            self.status.config(text="Playlist is empty.")
            return

        # Increment play count for each track in the playlist
        for key in self.playlist:
            self.library.increment_play_count(key)

        if self.on_play_queue is not None:
            # Pass the full playlist and start from index 0 (the first track)
            self.on_play_queue(self.playlist, 0)

        self.refresh_playlist()  # update play count display
        self.status.config(text="Playlist played. Play count updated.")

    def play_from_double_click(self, event=None):
        """
        Start playback from the double-clicked position in the playlist.
        Increments the play count for the selected track only.
        """
        index = self.get_selected_playlist_index()
        if index is None:
            return

        # Increment only the selected track's play count
        self.library.increment_play_count(self.playlist[index])

        if self.on_play_queue is not None:
            # Start the queue from the chosen index, not necessarily the beginning
            self.on_play_queue(self.playlist, index)

        self.refresh_playlist()
        self.status.config(text=f"Playing playlist from position {index + 1}.")

    def remove_selected_clicked(self):
        """Remove the highlighted track from the playlist."""
        index = self.get_selected_playlist_index()
        if index is None:
            self.status.config(text="Select a playlist item to remove.")
            return
        removed_key = self.playlist.pop(index)  # remove the key at this index
        self.refresh_playlist()
        self.status.config(text=f"Removed track {removed_key} from playlist.")

    def reset_playlist_clicked(self):
        """Clear all tracks from the playlist."""
        self.playlist = []          # replace with an empty list
        self.refresh_playlist()
        self.status.config(text="Playlist cleared.")

    # -------------------------------------------------------------------------
    # Save / Load Playlist as CSV
    # -------------------------------------------------------------------------

    def save_playlist_clicked(self):
        """
        Save the current playlist to a CSV file chosen by the user.
        Each row in the CSV contains: track key, track name, artist name.
        This stores enough information to reconstruct the playlist later,
        and also makes the file human-readable when opened in a spreadsheet.
        """
        if not self.playlist:
            self.status.config(text="Playlist is empty. Add tracks before saving.")
            return

        # Open a Save File dialog; defaultextension ensures .csv is appended if omitted
        file_path = filedialog.asksaveasfilename(
            title="Save Playlist as CSV",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if file_path == "":
            return  # user cancelled the dialog

        # Write the playlist to a CSV file
        with open(file_path, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            # Write a header row so the CSV is self-documenting
            writer.writerow(["key", "name", "artist", "rating", "play_count"])
            for key in self.playlist:
                item = self.library.get_item(key)
                if item is not None:
                    writer.writerow([key, item.name, item.artist,
                                     item.rating, item.play_count])

        self.status.config(text=f"Playlist saved to {os.path.basename(file_path)}.")

    def load_playlist_clicked(self):
        """
        Load a playlist from a CSV file chosen by the user.
        Only the track key column is used to rebuild the playlist;
        name and artist columns are ignored (they are for human readability only).
        Invalid or missing keys are silently skipped.
        """
        file_path = filedialog.askopenfilename(
            title="Load Playlist from CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if file_path == "":
            return  # user cancelled the dialog

        loaded_playlist = []

        with open(file_path, "r", encoding="utf-8") as csv_file:
            reader = csv.DictReader(csv_file)   # DictReader uses the header row as column names
            for row in reader:
                key = row.get("key", "").strip()    # read the "key" column; strip whitespace
                # Only add the key if it actually exists in the current library
                if key and self.library.get_item(key) is not None:
                    loaded_playlist.append(key)

        self.playlist = loaded_playlist     # replace current playlist with loaded one
        self.refresh_playlist()
        self.status.config(text=f"Loaded {len(self.playlist)} track(s) from CSV.")


# -------------------------------------------------------------------------
# Standalone test entry point
# -------------------------------------------------------------------------

if __name__ == "__main__":
    # Allows create_track_list.py to be run directly for isolated testing
    root = tk.Tk()
    root.title("Create Track List")
    style.setup_style(root)
    TrackListCreator(root, TrackLibrary())
    root.mainloop()
