import os
import tkinter as tk
from tkinter import ttk

import app_style as style
from font_manager import FontManager
from track_library import TrackLibrary

# Try to import PIL for image display; if not installed, image features are disabled
try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

class TrackViewer:
    """GUI section for viewing, searching and filtering tracks."""

    def __init__(self, window, library, on_play_track=None):
        """
        Initialise the TrackViewer.

        Parameters:
            window       - the parent Tkinter frame this section is placed inside
            library      - a TrackLibrary instance providing access to all track data
            on_play_track - optional callback function called with a track key when
                            the user requests playback (used by the main JukeBox window)
        """
        self.window = window                  # parent frame (section container)
        self.library = library                # reference to the shared track database
        self.on_play_track = on_play_track    # callback to trigger actual playback
        self.selected_key = None              # key of the currently selected track
        self.current_photo = None             # holds ImageTk reference to prevent garbage collection

        # StringVar objects are Tkinter-observable variables bound to widgets
        self.search_text = tk.StringVar()                    # bound to the search entry field
        self.artist_choice = tk.StringVar(value="All Artists")  # bound to the artist dropdown

        self.build_widgets()    # construct all GUI elements
        self.list_all_tracks()  # populate the list with all tracks on startup

    # Widget Construction
    def build_widgets(self):
        """Build and arrange all GUI widgets for this section."""
        # Section title label displayed at the top of the panel
        title = tk.Label(
            self.window,
            text="View Tracks",
            bg=style.PANEL,
            fg=style.ACCENT,
            font=FontManager.SECTION_FONT
        )
        title.pack(anchor="w", pady=(0, 10))  # align left with bottom padding

        # --- Top control bar: Search, List All, Artist filter ---
        top = ttk.Frame(self.window, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 12))  # stretch horizontally, gap below

        # Search label and entry field
        ttk.Label(top, text="Search:", style="Card.TLabel").pack(side="left")
        ttk.Entry(top, textvariable=self.search_text, width=25).pack(side="left", padx=5)

        # Search button triggers search_tracks(); styled as primary accent button
        ttk.Button(top, text="Search", command=self.search_tracks,
                   style="Accent.TButton").pack(side="left", padx=5)

        # List All button resets filters and shows every track
        ttk.Button(top, text="List All",
                   command=self.list_all_tracks).pack(side="left", padx=5)

        # Artist filter: dropdown (OptionMenu) populated from library's artist list
        ttk.Label(top, text="Artist:", style="Card.TLabel").pack(side="left", padx=(20, 5))
        self.artist_box = tk.OptionMenu(top, self.artist_choice, *self.get_artist_options())
        style.style_option_menu(self.artist_box)  # apply dark theme styling to dropdown
        self.artist_box.pack(side="left")

        # Filter button applies the selected artist filter
        ttk.Button(top, text="Filter",
                   command=self.filter_tracks).pack(side="left", padx=5)

        # --- Main area: track list (left) + detail panel (right) ---
        main = ttk.Frame(self.window, style="Card.TFrame")
        main.pack(fill="both", expand=True)  # stretch to fill all available space

        # Left panel: scrollable track list
        left = ttk.Frame(main, style="Card.TFrame")
        left.pack(side="left", fill="both", expand=True)

        # Sub-title above the track list
        tk.Label(
            left,
            text="Track Library",
            bg=style.PANEL,
            fg=style.SECONDARY,
            font=FontManager.SUBTITLE_FONT
        ).pack(anchor="w", pady=(0, 6))

        # Column header row displayed above the Listbox
        self.track_header = tk.Label(
            left,
            text=self.format_header(),  # fixed-width formatted string: No / Track / Artist / Rating / Plays
            bg=style.LIST_BG,
            fg=style.MUTED,
            anchor="w",
            font=FontManager.LIST_HEADER_FONT,
            padx=6,
            pady=4
        )
        self.track_header.pack(fill="x")

        # Listbox displays all tracks as formatted rows
        self.track_list = tk.Listbox(left, height=18)
        style.style_listbox(self.track_list)  # apply dark theme colours and font
        self.track_list.pack(fill="both", expand=True)

        # Bind single-click to show track details on selection
        self.track_list.bind("<<ListboxSelect>>", self.track_clicked)
        # Bind double-click to immediately play the selected track
        self.track_list.bind("<Double-Button-1>", self.track_double_clicked)

        # Right panel: album art + track details + play button
        right = ttk.Frame(main, style="Card.TFrame", width=220)
        right.pack(side="left", fill="y", padx=(10, 0))
        right.pack_propagate(False)

        # Play Selected button is packed first with side="bottom" so it always
        # stays at the bottom regardless of image height
        ttk.Button(right, text="▶  Play Selected",
                   command=self.play_selected,
                   style="Accent.TButton").pack(side="bottom", fill="x", pady=(8, 0))

        # Image label shows album art when a track is selected; defaults to "No Image"
        self.image_label = ttk.Label(right, text="No Image", anchor="center",
                                     style="Card.TLabel")
        self.image_label.pack(pady=(0, 8))

        # Text widget shows full track details (name, artist, rating, play count, album)
        self.details = tk.Text(right, width=34, height=10, wrap="word")
        style.style_text(self.details)  # apply dark theme to text widget
        self.details.pack(fill="x")

        # Status bar at the bottom: shows feedback messages to the user
        self.status = ttk.Label(self.window, text="Click a track to view details.",
                                style="Status.TLabel")
        self.status.pack(fill="x", pady=(10, 0))

    # Helper Methods
    def set_details(self, text):
        """
        Replace the content of the details Text widget with the given text.
        Clears existing content before inserting new text.
        """
        self.details.delete("1.0", tk.END)   # "1.0" means line 1, character 0 (the start)
        self.details.insert("1.0", text)      # insert new content at the beginning

    def refresh(self):
        """
        Refresh the artist dropdown and reload all tracks.
        Called automatically when switching back to this section.
        """
        # Rebuild the artist dropdown with the latest list from the library
        menu = self.artist_box["menu"]
        menu.delete(0, "end")  # remove all existing menu entries
        for artist in self.get_artist_options():
            # add_command creates a menu item; lambda captures the current artist value
            menu.add_command(label=artist,
                             command=lambda value=artist: self.artist_choice.set(value))
        style.style_option_menu(self.artist_box)  # reapply styling after rebuild
        self.list_all_tracks()  # reset list to show all tracks

    def get_artist_options(self):
        """Return a list starting with 'All Artists' followed by all unique artists."""
        return ["All Artists"] + self.library.get_artists()

    def format_header(self):
        """Return a fixed-width column header string for the track list."""
        # f-string with :<N format specifies left-justified padding to N characters
        return f"{'No':<4}{'Track':<34}{'Artist':<24}{'Rating':<10}{'Plays':<6}"

    def format_track_row(self, key, item):
        """
        Format a single track as a fixed-width string for display in the Listbox.
        Long names are truncated to prevent overflow into adjacent columns.
        """
        return (
            f"{key:<4}"
            f"{item.name[:32]:<34}"      # truncate name to 32 chars, pad to 34
            f"{item.artist[:22]:<24}"    # truncate artist to 22 chars, pad to 24
            f"{item.stars():<10}"        # star rating string e.g. "★★★☆☆"
            f"{item.play_count:<6}"      # integer play count
        )

    # Track List Display
    def show_tracks(self, items):
        """
        Clear the Listbox and repopulate it with the given list of (key, item) pairs.

        Parameters:
            items - list of (key, LibraryItem) tuples to display
        """
        self.track_list.delete(0, tk.END)   # remove all existing rows from the Listbox
        for key, item in items:
            # insert each formatted row at the end of the Listbox
            self.track_list.insert(tk.END, self.format_track_row(key, item))

    def list_all_tracks(self):
        """Reset all filters and display every track in the library."""
        self.search_text.set("")                    # clear the search entry field
        self.artist_choice.set("All Artists")       # reset the artist dropdown
        self.show_tracks(self.library.get_all_items())  # fetch and display all tracks
        self.status.config(text="All tracks displayed.")

    def search_tracks(self):
        """Search the library by the keyword in the search field and display results."""
        keyword = self.search_text.get()            # read the current search text
        results = self.library.search(keyword)      # returns dict of matching {key: item}
        self.show_tracks(list(results.items()))     # convert dict to list of tuples
        self.status.config(text=f"{len(results)} matching track(s).")

    def filter_tracks(self):
        """Filter the track list to show only tracks by the selected artist."""
        artist = self.artist_choice.get()
        if artist == "All Artists":
            self.list_all_tracks()  # show everything if no specific artist chosen
            return
        results = self.library.filter_by_artist(artist)  # returns dict of matching tracks
        self.show_tracks(list(results.items()))
        self.status.config(text=f"{len(results)} track(s) by {artist}.")

    # Selection and Detail Display
    def get_selected_key(self):
        """
        Return the track key of the currently highlighted row in the Listbox.
        Returns None if nothing is selected.
        """
        selected = self.track_list.curselection()  # returns tuple of selected indices
        if not selected:
            return None
        line = self.track_list.get(selected[0])    # get the text of the selected row
        return line.split()[0]                     # the key is the first whitespace-delimited token

    def track_clicked(self, event=None):
        """Handle single-click on the track list: show details for the selected track."""
        key = self.get_selected_key()
        if key is not None:
            self.show_details(key)  # populate the details panel on the right

    def track_double_clicked(self, event=None):
        """Handle double-click on the track list: immediately play the selected track."""
        self.play_selected()

    def show_details(self, key):
        """
        Display full information for the track with the given key in the details panel.
        Also loads and displays the track's album art image.

        Parameters:
            key - the two-digit string key identifying the track (e.g. "04")
        """
        item = self.library.get_item(key)  # retrieve the LibraryItem object
        if item is None:
            self.status.config(text="Track not found.")
            return

        self.selected_key = key  # remember this key for the Play Selected button

        # Build a multi-line detail string showing all track attributes
        text = (
            f"Track #:  {key}\n"
            f"Name:    {item.name}\n"
            f"Artist:  {item.artist}\n"
            f"Type:    {item.media_type()}\n"   # "Music Track" or "Album Track"
            f"Rating:  {item.rating}/5\n"
            f"Stars:   {item.stars()}\n"
            f"Plays:   {item.play_count}\n"
        )

        # AlbumTrack objects have an 'album' attribute; add it if present
        if hasattr(item, "album"):
            text += f"Album:   {item.album}\n"

        self.set_details(text)              # write the detail text to the Text widget
        self.show_image(item.image_path)    # attempt to load and display the album art
        self.status.config(text=f"Showing details for track {key}.")

    def show_image(self, image_path):
        """
        Load and display the album art image from the given file path.
        Falls back to a "No Image" placeholder if PIL is unavailable or the file is missing.

        Parameters:
            image_path - absolute path string to the image file
        """
        # Check all conditions that would prevent image display
        if not HAS_PIL or not image_path or not os.path.exists(image_path):
            self.current_photo = None
            self.image_label.config(image="", text="No Image")
            return

        image = Image.open(image_path)      # open the image file using Pillow
        image.thumbnail((180, 160))         # scale down while preserving aspect ratio; max 220x220 px
        # Convert to a Tkinter-compatible PhotoImage object
        self.current_photo = ImageTk.PhotoImage(image)
        # Store in self.current_photo to prevent Python garbage collection from deleting it
        self.image_label.config(image=self.current_photo, text="")  # display image, hide text

    # Playback
    def play_selected(self):
        """
        Play the currently selected (or last viewed) track.
        Uses the on_play_track callback if available; otherwise simulates playback
        by incrementing the play count directly.
        """
        # Prefer the Listbox selection; fall back to the last viewed track key
        key = self.get_selected_key() or self.selected_key
        if key is None:
            self.status.config(text="Please select a track first.")
            return

        if self.on_play_track is not None:
            # Delegate actual audio playback to the JukeBox main window
            self.on_play_track(key)
            self.status.config(text=f"Playing track {key}.")
        else:
            # Simulation mode: increment play count without audio
            self.library.increment_play_count(key)
            self.status.config(text=f"Simulated playing track {key}.")


# Standalone test entry point
if __name__ == "__main__":
    # Allows view_tracks.py to be run directly for isolated testing
    root = tk.Tk()
    root.title("View Tracks")
    style.setup_style(root)
    TrackViewer(root, TrackLibrary())
    root.mainloop()
