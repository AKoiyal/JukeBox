import tkinter as tk
from tkinter import ttk
from font_manager import FontManager

# ── Colour palette ──────────────────────────────────────────────────────────
BG           = "#0d1117"
PANEL        = "#161b22"
PANEL_LIGHT  = "#1c2230"
TEXT         = "#e6edf3"
TEXT_ON_DARK = "#f0f6fc"
MUTED        = "#8b949e"
ACCENT       = "#2ea043"
ACCENT_DARK  = "#238636"
SECONDARY    = "#1f6feb"
SUCCESS      = "#2ea043"
DANGER       = "#f85149"

LIST_BG      = "#0d1117"
LIST_SELECT  = "#1a3a2a"
PROGRESS_BG  = "#21262d"

BORDER       = "#30363d"
INPUT_BG     = "#0d1117"
BUTTON_BG    = "#21262d"
BUTTON_HOVER = "#30363d"
NAV_BG       = "#161b22"
NAV_HOVER    = "#21262d"


# ── Master setup ─────────────────────────────────────────────────────────────
def setup_style(window):
    window.configure(bg=BG)
    window.option_add("*tearOff", False)
    FontManager().configure()

    s = ttk.Style(window)
    if "clam" in s.theme_names():
        s.theme_use("clam")

    # ── Frames
    s.configure("TFrame",          background=BG)
    s.configure("Card.TFrame",     background=PANEL)
    s.configure("Player.TFrame",   background=PANEL_LIGHT)
    s.configure("Sidebar.TFrame",  background=PANEL)

    # ── Labels
    s.configure("TLabel",          background=BG,          foreground=TEXT,         font=FontManager.BODY_FONT)
    s.configure("Card.TLabel",     background=PANEL,       foreground=TEXT,         font=FontManager.BODY_FONT)
    s.configure("Player.TLabel",   background=PANEL_LIGHT, foreground=TEXT_ON_DARK, font=FontManager.BODY_FONT)
    s.configure("Header.TLabel",   background=BG,          foreground=MUTED,        font=("Segoe UI", 10))
    s.configure("Title.TLabel",    background=BG,          foreground=TEXT,         font=FontManager.TITLE_FONT)
    s.configure("Section.TLabel",  background=PANEL,       foreground=TEXT,         font=FontManager.SECTION_FONT)
    s.configure("Status.TLabel",   background=PANEL,       foreground=MUTED,        font=FontManager.SMALL_FONT)
    s.configure("Sidebar.TLabel",  background=PANEL,       foreground=MUTED,        font=("Segoe UI", 9, "bold"))

    # ── Normal button
    s.configure("TButton",
                font=FontManager.SMALL_FONT, padding=(14, 9),
                background=BUTTON_BG, foreground=TEXT,
                borderwidth=0, relief="flat", focusthickness=0)
    s.map("TButton",
          background=[("active", BUTTON_HOVER), ("pressed", BUTTON_HOVER)],
          foreground=[("disabled", "#484f58")])

    # ── Accent (green) button
    s.configure("Accent.TButton",
                font=FontManager.SMALL_FONT, padding=(14, 9),
                background=ACCENT, foreground="#ffffff",
                borderwidth=0, relief="flat", focusthickness=0)
    s.map("Accent.TButton",
          background=[("active", ACCENT_DARK), ("pressed", ACCENT_DARK)],
          foreground=[("active", "#ffffff"), ("pressed", "#ffffff")])

    # ── Blue button (previously "Purple")
    s.configure("Purple.TButton",
                font=FontManager.SMALL_FONT, padding=(14, 9),
                background=SECONDARY, foreground="#ffffff",
                borderwidth=0, relief="flat", focusthickness=0)
    s.map("Purple.TButton",
          background=[("active", "#1158c7"), ("pressed", "#1158c7")],
          foreground=[("active", "#ffffff"), ("pressed", "#ffffff")])

    # ── Sidebar nav — inactive
    s.configure("Nav.TButton",
                font=("Segoe UI", 10), padding=(16, 11),
                background=NAV_BG, foreground=MUTED,
                borderwidth=0, relief="flat", focusthickness=0, anchor="w")
    s.map("Nav.TButton",
          background=[("active", NAV_HOVER), ("pressed", NAV_HOVER)],
          foreground=[("active", TEXT), ("pressed", TEXT)])

    # ── Sidebar nav — active
    s.configure("Nav.Active.TButton",
                font=("Segoe UI", 10, "bold"), padding=(16, 11),
                background=ACCENT, foreground="#ffffff",
                borderwidth=0, relief="flat", focusthickness=0, anchor="w")
    s.map("Nav.Active.TButton",
          background=[("active", ACCENT_DARK), ("pressed", ACCENT_DARK)],
          foreground=[("active", "#ffffff"), ("pressed", "#ffffff")])

    # ── Entry
    s.configure("TEntry",
                fieldbackground=INPUT_BG, foreground=TEXT,
                insertcolor=TEXT, borderwidth=1, relief="flat",
                padding=(10, 7))
    s.map("TEntry", fieldbackground=[("focus", INPUT_BG)])

    # ── Combobox
    s.configure("TCombobox",
                fieldbackground=INPUT_BG, background=INPUT_BG,
                foreground=TEXT, arrowcolor=MUTED,
                borderwidth=1, relief="flat", padding=(8, 6))
    s.map("TCombobox",
          fieldbackground=[("readonly", INPUT_BG)],
          background=[("readonly", INPUT_BG)],
          foreground=[("readonly", TEXT)])

    # ── LabelFrame
    s.configure("TLabelframe",
                background=PANEL, foreground=TEXT,
                borderwidth=1, relief="groove",
                bordercolor=BORDER)
    s.configure("TLabelframe.Label",
                background=PANEL, foreground=MUTED,
                font=FontManager.SUBTITLE_FONT)

    # ── Scale
    s.configure("Horizontal.TScale",
                background=PANEL_LIGHT,
                troughcolor=PROGRESS_BG,
                borderwidth=0)

    # ── Separator
    s.configure("TSeparator", background=BORDER)


# ── Helper constructors ───────────────────────────────────────────────────────
def card(parent, padding=18):
    return ttk.Frame(parent, style="Card.TFrame", padding=padding)


def style_listbox(listbox):
    listbox.configure(
        bg=LIST_BG,
        fg=TEXT,
        selectbackground=LIST_SELECT,
        selectforeground=TEXT,
        relief="flat",
        borderwidth=0,
        highlightthickness=1,
        highlightbackground="#333333",
        activestyle="none",
        font=FontManager.LIST_FONT,
    )


def style_text(text_widget):
    text_widget.configure(
        bg=LIST_BG, fg=TEXT,
        insertbackground=TEXT,
        relief="flat", borderwidth=0,
        highlightthickness=1,
        highlightbackground=BORDER,
        highlightcolor=ACCENT,
        font=FontManager.BODY_FONT,
        padx=14, pady=12,
        spacing1=3, spacing2=2, spacing3=3
    )


def style_option_menu(menu_button):
    menu_button.configure(
        bg=INPUT_BG, fg=TEXT,
        activebackground=BUTTON_HOVER, activeforeground=TEXT,
        relief="flat", borderwidth=0,
        highlightthickness=1,
        highlightbackground=BORDER,
        highlightcolor=ACCENT,
        font=FontManager.SMALL_FONT,
        padx=12, pady=6,
        cursor="hand2"
    )
    menu = menu_button["menu"]
    menu.configure(
        bg=BUTTON_BG, fg=TEXT,
        activebackground=LIST_SELECT, activeforeground=TEXT_ON_DARK,
        relief="flat", borderwidth=0,
        font=FontManager.SMALL_FONT
    )
