class LibraryItem:
    """A single music track in the jukebox library."""

    def __init__(self, name, artist, rating=0, audio_path="", image_path=""):
        self._name = name
        self._artist = artist
        self._rating = 0
        self._play_count = 0
        self._audio_path = audio_path
        self._image_path = image_path
        self.set_rating(rating)

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value

    @property
    def artist(self):
        return self._artist

    @artist.setter
    def artist(self, value):
        self._artist = value

    @property
    def rating(self):
        return self._rating

    @property
    def play_count(self):
        return self._play_count

    @property
    def audio_path(self):
        return self._audio_path

    @audio_path.setter
    def audio_path(self, value):
        self._audio_path = value

    @property
    def image_path(self):
        return self._image_path

    @image_path.setter
    def image_path(self, value):
        self._image_path = value

    def stars(self):
        return "★" * self.rating + "☆" * (5 - self.rating)

    def media_type(self):
        return "Music Track"

    def info(self):
        return f"{self.name} - {self.artist} {self.stars()}"

    def set_rating(self, rating):
        if isinstance(rating, int) and 0 <= rating <= 5:
            self._rating = rating

    def increment_play_count(self):
        self._play_count += 1

    def matches_artist(self, artist):
        return self.artist.lower() == artist.lower()

    def matches_keyword(self, keyword):
        keyword = keyword.lower()
        return keyword in self.name.lower() or keyword in self.artist.lower()


class AlbumTrack(LibraryItem):
    """A music track that also stores its album name."""

    def __init__(self, name, artist, album, rating=0, audio_path="", image_path=""):
        super().__init__(name, artist, rating, audio_path, image_path)
        self._album = album

    @property
    def album(self):
        return self._album

    @album.setter
    def album(self, value):
        self._album = value

    def media_type(self):
        return "Album Track"

    def info(self):
        return f"{self.name} - {self.artist} ({self.album}) {self.stars()}"

    def matches_keyword(self, keyword):
        keyword = keyword.lower()
        return super().matches_keyword(keyword) or keyword in self.album.lower()
